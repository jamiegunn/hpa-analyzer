"""Plain-text report renderer: scorecard, findings, proof tables, education."""

import textwrap
from datetime import datetime
from typing import List

from . import __version__
from .models import AnalysisResult, Category, ProofTable, Severity
from .scoring import WEIGHTS, category_scores, grade, overall_score

WIDTH = 100


def _hr(char="=") -> str:
    return char * WIDTH


def _wrap(text: str, indent: int = 0, width: int = WIDTH) -> str:
    pad = " " * indent
    out_lines: List[str] = []
    for para in (text or "").split("\n"):
        if not para.strip():
            out_lines.append("")
            continue
        out_lines.extend(textwrap.wrap(
            para, width=width - indent, initial_indent=pad,
            subsequent_indent=pad, break_long_words=False,
            break_on_hyphens=False) or [pad])
    return "\n".join(out_lines)


def _section(title: str, number: str = "") -> str:
    head = f"{number}  {title}" if number else title
    return f"\n\n{_hr('=')}\n{head.upper()}\n{_hr('=')}\n"


# ---------------------------------------------------------------------------
# ASCII tables with cell wrapping
# ---------------------------------------------------------------------------

def _table(headers: List[str], rows: List[List[str]], width: int = WIDTH) -> str:
    cols = len(headers)
    rows = [[("" if c is None else str(c)) for c in r] + [""] * (cols - len(r))
            for r in rows]
    naturals = [max(len(headers[i]), *(len(r[i]) for r in rows)) if rows
                else len(headers[i]) for i in range(cols)]
    budget = width - (3 * cols + 1)
    widths = list(naturals)
    if sum(widths) > budget:
        # shrink widest columns first, floor of 8 chars
        while sum(widths) > budget and max(widths) > 8:
            j = widths.index(max(widths))
            widths[j] -= 1
    def fmt_row(cells: List[str], sep="|") -> List[str]:
        wrapped = [textwrap.wrap(c, widths[i], break_long_words=True,
                                 break_on_hyphens=False) or [""]
                   for i, c in enumerate(cells)]
        height = max(len(w) for w in wrapped)
        lines = []
        for h in range(height):
            parts = [(wrapped[i][h] if h < len(wrapped[i]) else "").ljust(widths[i])
                     for i in range(cols)]
            lines.append(f"{sep} " + f" {sep} ".join(parts) + f" {sep}")
        return lines
    border = "+" + "+".join("-" * (w + 2) for w in widths) + "+"
    out = [border]
    out.extend(fmt_row(headers))
    out.append(border.replace("-", "="))
    for r in rows:
        out.extend(fmt_row(r))
        out.append(border)
    return "\n".join(out)


# ---------------------------------------------------------------------------
# Report body
# ---------------------------------------------------------------------------

def render(result: AnalysisResult, target: str) -> str:
    ctx = result.context
    findings = sorted(
        result.findings,
        key=lambda f: (-f.severity.rank, -WEIGHTS[f.category], f.rule_id))
    score = overall_score(result)
    g = grade(score) if score is not None else "-"
    counts = {s: sum(1 for f in findings if f.severity is s) for s in Severity}

    L: List[str] = []
    L.append(_hr())
    L.append("HELM CHART / KUBERNETES / JVM QUALITY ANALYSIS".center(WIDTH))
    L.append(f"hpa-analyzer v{__version__}".center(WIDTH))
    L.append(_hr())
    L.append(f"Target directory : {target}")
    L.append(f"Generated        : {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    L.append(f"Chart            : "
             f"{ctx.chart.get('name', '(none)')} "
             f"v{ctx.chart.get('version', '?')} "
             f"(appVersion {ctx.chart.get('appVersion', '?')})"
             if ctx.chart else "Chart            : NOT FOUND")

    # inventory
    L.append("\nFiles analyzed:")
    inv = []
    if ctx.chart_yaml_path:
        inv.append(f"  chart      : {ctx.chart_yaml_path}")
    for p in ctx.values_files:
        inv.append(f"  values     : {p}")
    for p in ctx.template_files:
        inv.append(f"  template   : {p}")
    for d in ctx.dockerfiles:
        java = (f"Java {d.java_major}" + (f"u{d.java_update}" if d.java_update
                and d.java_major == 8 else
                (f".0.{d.java_update}" if d.java_update and d.java_major != 8 else ""))
                if d.java_major else "Java version unknown")
        inv.append(f"  dockerfile : {d.path}  [{java}"
                   f"{', ' + d.java_flavor if d.java_flavor else ''}]")
    L.extend(inv or ["  (nothing found)"])

    # ----- executive summary ------------------------------------------------
    L.append(_section("1. Executive summary"))
    if score is None:
        L.append("  OVERALL QUALITY SCORE : NOT GRADED")
        L.append(_wrap("No analyzable chart, values, templates or Dockerfile "
                       "were found under the target directory. A score here "
                       "would be a statement about nothing - see the findings "
                       "and the coverage section for what is missing.", indent=2))
    else:
        bar = int(round(score / 2))
        L.append(f"  OVERALL QUALITY SCORE : {score:5.1f} / 100   GRADE: {g}")
        L.append(f"  [{'#' * bar}{'.' * (50 - bar)}]")
    L.append(f"  Analysis mode         : {ctx.render_mode}")
    L.append("")
    L.append(f"  Findings: {counts[Severity.CRITICAL]} critical, "
             f"{counts[Severity.HIGH]} high, {counts[Severity.MEDIUM]} medium, "
             f"{counts[Severity.LOW]} low, {counts[Severity.INFO]} info")
    crits = [f for f in findings if f.severity is Severity.CRITICAL]
    if crits:
        L.append("\n  Fix these first (each is an outage or a dead feature, not a style issue):")
        for i, f in enumerate(crits[:5], 1):
            L.append(_wrap(f"{i}. [{f.rule_id}] {f.title}"
                           + (f"  ({f.file})" if f.file else ""), indent=4))
    elif counts[Severity.HIGH]:
        L.append("\n  No critical findings; start with the HIGH severity list below.")
    else:
        L.append("\n  No critical or high findings - solid baseline.")

    # ----- coverage ----------------------------------------------------------
    L.append(_section("2. Analysis coverage - what was and was NOT checked"))
    L.append(_wrap(
        "Findings can only come from files that were successfully analyzed. "
        "Anything marked as failed, skipped or unknown below produced NO "
        "findings - treat that as missing coverage, never as a clean bill "
        "of health."))
    L.append("")
    if ctx.coverage:
        L.append(_table(["Input", "Coverage"],
                        [list(row) for row in ctx.coverage]))
    else:
        L.append("  (no coverage records - nothing was analyzable)")
    if ctx.render_mode == "helm":
        L.append(_wrap("\nMode: `helm template` rendered the chart with its "
                       "real template engine - manifests below are rendered "
                       "truth for the analyzed values. Objects marked "
                       "'conditional' exist in templates but do not render "
                       "with these values.", indent=0))
    else:
        L.append(_wrap(f"\nMode: {ctx.render_mode}. Static scrubbing "
                       f"approximates helm rendering: conditionals are "
                       f"analyzed as taken and complex template expressions "
                       f"may hide configuration from these checks. Install "
                       f"helm on PATH and re-run for rendered-truth analysis "
                       f"- it materially improves precision.", indent=0))

    # ----- scorecard ----------------------------------------------------------
    L.append(_section("3. Scorecard by category"))
    rows = []
    for cat, cscore, cfind in category_scores(result):
        n_by_sev = ", ".join(
            f"{sum(1 for f in cfind if f.severity is s)}{s.label[0]}"
            for s in (Severity.CRITICAL, Severity.HIGH, Severity.MEDIUM,
                      Severity.LOW) if any(f.severity is s for f in cfind)) or "-"
        rows.append([
            cat.value,
            "N/A" if cscore is None else f"{cscore:5.1f}",
            "N/A" if cscore is None else grade(cscore),
            str(WEIGHTS[cat]),
            n_by_sev,
        ])
    L.append(_table(["Category", "Score", "Grade", "Weight", "Findings (C/H/M/L)"], rows))
    L.append(_wrap("\nScoring model: each category starts at 100; deductions "
                   "are CRITICAL -25, HIGH -12, MEDIUM -6, LOW -3, INFO -0, "
                   "floored at 0. Overall = weighted mean over applicable "
                   "categories (N/A categories are excluded, not free points)."))

    # ----- findings -----------------------------------------------------------
    L.append(_section("4. Findings and remediation"))
    if not findings:
        L.append("  No findings. Exceptional.")
    order = [Severity.CRITICAL, Severity.HIGH, Severity.MEDIUM, Severity.LOW,
             Severity.INFO]
    for sev in order:
        sel = [f for f in findings if f.severity is sev]
        if not sel:
            continue
        L.append(f"\n{_hr('-')}")
        L.append(f"{sev.label}  ({len(sel)})")
        L.append(_hr("-"))
        if sev is Severity.INFO:
            L.append(_wrap("Housekeeping items - zero score impact, one line "
                           "each so they stop competing with real problems:",
                           indent=2))
            for f in sel:
                loc = f" ({f.file})" if f.file else ""
                L.append(_wrap(f"[{f.rule_id}] {f.title}{loc} -> {f.fix}",
                               indent=4))
            continue
        for f in sel:
            loc = f" | {f.file}" + (f":{f.line}" if f.line else "") if f.file else ""
            L.append(f"\n[{f.rule_id}] {f.title}")
            L.append(f"    Category: {f.category.value}{loc}")
            L.append(_wrap(f"Found : {f.detail}", indent=4))
            L.append(_wrap(f"Why   : {f.why}", indent=4))
            if f.math:
                L.append(_wrap(f"Math  : {f.math}", indent=4))
            L.append(_wrap(f"Fix   : {f.fix}", indent=4))

    # ----- proof tables -------------------------------------------------------
    L.append(_section("5. Mathematical proof tables"))
    L.append(_wrap("Every table below derives its verdict from arithmetic on "
                   "values found in YOUR files (estimates are labeled and "
                   "conservative). Re-check any number by hand."))
    if not result.proofs:
        L.append("\n  (No workload/JVM pairs found to compute tables for.)")
    for i, p in enumerate(result.proofs, 1):
        L.append(f"\n{_hr('-')}")
        L.append(f"TABLE {i}: {p.title}")
        L.append(_hr("-"))
        L.append(_wrap(p.intro))
        L.append("")
        L.append(_table(p.headers, p.rows))
        L.append("")
        L.append(_wrap("VERDICT: " + p.conclusion, indent=2))

    # ----- education ----------------------------------------------------------
    L.append(_section("6. Education appendix - why this math matters"))
    L.append(_education())

    # ----- methodology --------------------------------------------------------
    L.append(_section("7. Methodology and limitations"))
    if ctx.render_mode == "helm":
        mode_para = (
            "Manifests were produced by `helm template` - the real template "
            "engine with the analyzed values - so conditional logic, loops "
            "and helpers are evaluated exactly as a deploy would. Templates "
            "that do not render with these values were additionally analyzed "
            "statically and are labeled 'conditional' wherever they appear. ")
    else:
        mode_para = (
            f"Analysis mode: {ctx.render_mode}. Templates were parsed with "
            "Go-template expressions scrubbed and, where possible, resolved "
            "from values.yaml, WITHOUT executing helm. Conditional blocks "
            "are analyzed as if taken; complex expressions (tpl, printf, "
            "required, subcharts) are beyond static resolution and files "
            "that failed to parse produced no findings at all - the "
            "coverage section lists every such gap. Installing helm and "
            "re-running upgrades this report to rendered-truth analysis. ")
    L.append(_wrap(
        mode_para +
        "Numeric estimates (metaspace, thread counts, node sizes, startup "
        "times, per-pod availability) are stated inline and should be "
        "replaced with your measured values for final sizing decisions; "
        "conclusions drawn from estimates say so. Complement this report "
        "with: helm lint && helm template | kubeconform, a policy engine "
        "(Polaris/Kyverno/OPA), and real load-test data with GC logs "
        "(-Xlog:gc* / -XX:+PrintGCDetails) and kubectl top / VPA "
        "recommendations."))
    L.append("\n" + _hr())
    L.append("END OF REPORT".center(WIDTH))
    L.append(_hr())
    return "\n".join(L) + "\n"


# ---------------------------------------------------------------------------
# Static education content
# ---------------------------------------------------------------------------

def _education() -> str:
    E: List[str] = []

    E.append("\n6.1  THE HPA CONTROL LOOP\n")
    E.append(_wrap(
        "Every ~15s the HPA computes, per metric:  desired = "
        "ceil(currentReplicas x currentValue / targetValue), takes the MAX "
        "across metrics, applies a +/-10% tolerance dead-band, clamps to "
        "[minReplicas, maxReplicas], then applies behavior policies "
        "(default: scale-up immediately, scale-down after a 300s "
        "stabilization window). Two facts follow directly from the formula:", indent=2))
    E.append(_wrap("(a) CPU 'utilization' is usage divided by the pod's "
                   "REQUEST - not its limit, not node capacity. Wrong "
                   "requests make the HPA scale wrongly, in exact "
                   "proportion.", indent=6))
    E.append(_wrap("(b) Any metric that does not fall when replicas rise "
                   "breaks the loop: desired can never go below current. "
                   "JVM memory is the canonical example (heap high-water "
                   "mark).", indent=6))

    E.append("\n6.2  THE JVM MEMORY MODEL IN A CONTAINER\n")
    E.append("      container limit (cgroup memory.max)  <-- kernel kills here (exit 137)")
    E.append("      +--------------------------------------------------+")
    E.append("      |  heap (-Xmx / MaxRAMPercentage)                  |")
    E.append("      |  metaspace (classes; unbounded by default!)      |")
    E.append("      |  JIT code cache                                  |")
    E.append("      |  thread stacks (threads x -Xss, ~1 MiB each)     |")
    E.append("      |  direct/NIO buffers (default cap = Xmx!)         |")
    E.append("      |  GC bookkeeping, symbols, JVM itself             |")
    E.append("      +--------------------------------------------------+")
    E.append(_wrap(
        "The kernel enforces the SUM. A heap that fits is necessary but not "
        "sufficient - rule of thumb: heap <= 50-75% of the limit, and never "
        "less than ~250-400 MiB of absolute non-heap headroom for framework "
        "apps. The kernel OOM kill (exit 137) produces NO Java stack trace "
        "and NO heap dump: if you see 137/OOMKilled with no "
        "OutOfMemoryError in logs, it was the cgroup, not the heap.", indent=2))

    E.append("\n6.3  JAVA CONTAINER-AWARENESS TIMELINE\n")
    E.append(_table(
        ["JVM", "Sees cgroup v1 limits?", "Sees cgroup v2?", "Heap % flags"],
        [
            ["Java 8 < 8u131", "NO - uses host RAM/CPUs", "NO", "-Xmx only"],
            ["8u131 - 8u190", "memory only, with -XX:+UnlockExperimentalVMOptions "
             "-XX:+UseCGroupMemoryLimitForHeap", "NO", "-Xmx, MaxRAMFraction"],
            ["8u191 - 8u371", "YES (UseContainerSupport backport, default on)",
             "NO", "MaxRAMPercentage"],
            ["8u372+", "YES", "YES", "MaxRAMPercentage"],
            ["11.0.0 - 11.0.15", "YES", "NO", "MaxRAMPercentage"],
            ["11.0.16+, 15+, 17, 21", "YES", "YES", "MaxRAMPercentage"],
        ]))
    E.append(_wrap(
        "cgroup v2 is the default on modern node images (Ubuntu 22.04+, "
        "EKS AL2023, current GKE/AKS). A pre-v2 JVM on a v2 node silently "
        "falls back to HOST sizing - the worst failure mode returns even "
        "though your JDK 'is container aware'.", indent=2))

    E.append("\n6.4  A SANE BASELINE FOR A JVM SERVICE CHART\n")
    E.append(_table(
        ["Setting", "Baseline", "Reason"],
        [
            ["requests.memory = limits.memory", "e.g. 1Gi / 1Gi",
             "memory is incompressible; Guaranteed-style memory QoS"],
            ["requests.cpu", "250m-1000m ~ typical usage", "HPA denominator; "
             "scheduler packing"],
            ["limits.cpu", "unset (or >= 2x request)",
             "avoid CFS throttling of GC/JIT bursts"],
            ["-XX:MaxRAMPercentage", "50-75", "heap scales with the limit"],
            ["-XX:+ExitOnOutOfMemoryError", "always", "die visibly; let K8s heal"],
            ["-XX:ActiveProcessorCount", "set if no cpu limit",
             "stable thread-pool sizing"],
            ["startupProbe", "period 5s x threshold 24-60",
             "protects slow JVM starts from liveness"],
            ["readiness != liveness", "always", "shed traffic without restarts"],
            ["HPA", "autoscaling/v2, CPU 60-75%, min >= 2",
             "headroom for scale-up lag"],
            ["PDB", "maxUnavailable: 1", "survive drains/upgrades"],
            ["replicas", "omit when HPA enabled",
             "helm upgrade must not reset scale"],
            ["ENTRYPOINT", "exec form (java as PID 1)",
             "SIGTERM -> graceful shutdown"],
        ]))

    E.append("\n6.5  GOLDEN RULES\n")
    for rule in (
        "1. The HPA divides by requests: requests ARE your scaling policy.",
        "2. The kernel sums everything: budget the whole JVM, not the heap.",
        "3. Kubernetes restarts what dies: make the JVM die on OOM, cleanly on SIGTERM.",
        "4. Never scale a JVM on memory utilization.",
        "5. Anything mutable ('latest', unpinned bases, helm-managed replicas "
        "under an HPA) will eventually mutate mid-incident.",
    ):
        E.append(_wrap(rule, indent=2))
    return "\n".join(E)
