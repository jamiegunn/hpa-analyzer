"""Shared Kubernetes helpers used by check modules."""

from typing import Any, Dict, List, Optional, Tuple

from .models import ManifestDoc

# apiVersion -> (removed_in, replacement)  (deprecated/removed APIs)
DEPRECATED_APIS: Dict[Tuple[str, str], Tuple[str, str]] = {
    ("extensions/v1beta1", "deployment"):            ("1.16", "apps/v1"),
    ("extensions/v1beta1", "daemonset"):             ("1.16", "apps/v1"),
    ("extensions/v1beta1", "replicaset"):            ("1.16", "apps/v1"),
    ("extensions/v1beta1", "ingress"):               ("1.22", "networking.k8s.io/v1"),
    ("extensions/v1beta1", "networkpolicy"):         ("1.16", "networking.k8s.io/v1"),
    ("extensions/v1beta1", "podsecuritypolicy"):     ("1.16", "policy/v1beta1 (PSP removed 1.25)"),
    ("apps/v1beta1", "deployment"):                  ("1.16", "apps/v1"),
    ("apps/v1beta2", "deployment"):                  ("1.16", "apps/v1"),
    ("apps/v1beta1", "statefulset"):                 ("1.16", "apps/v1"),
    ("apps/v1beta2", "statefulset"):                 ("1.16", "apps/v1"),
    ("apps/v1beta2", "daemonset"):                   ("1.16", "apps/v1"),
    ("autoscaling/v2beta1", "horizontalpodautoscaler"): ("1.25", "autoscaling/v2"),
    ("autoscaling/v2beta2", "horizontalpodautoscaler"): ("1.26", "autoscaling/v2"),
    ("policy/v1beta1", "poddisruptionbudget"):       ("1.25", "policy/v1"),
    ("policy/v1beta1", "podsecuritypolicy"):         ("1.25", "(removed - use Pod Security Standards)"),
    ("networking.k8s.io/v1beta1", "ingress"):        ("1.22", "networking.k8s.io/v1"),
    ("networking.k8s.io/v1beta1", "ingressclass"):   ("1.22", "networking.k8s.io/v1"),
    ("batch/v1beta1", "cronjob"):                    ("1.25", "batch/v1"),
    ("rbac.authorization.k8s.io/v1beta1", "clusterrole"): ("1.22", "rbac.authorization.k8s.io/v1"),
    ("rbac.authorization.k8s.io/v1beta1", "role"):   ("1.22", "rbac.authorization.k8s.io/v1"),
    ("storage.k8s.io/v1beta1", "csidriver"):         ("1.22", "storage.k8s.io/v1"),
    ("coordination.k8s.io/v1beta1", "lease"):        ("1.22", "coordination.k8s.io/v1"),
    ("discovery.k8s.io/v1beta1", "endpointslice"):   ("1.25", "discovery.k8s.io/v1"),
}

RECOMMENDED_LABELS = (
    "app.kubernetes.io/name",
    "app.kubernetes.io/instance",
    "app.kubernetes.io/version",
    "app.kubernetes.io/managed-by",
)


def pod_spec(doc: ManifestDoc) -> Optional[Dict[str, Any]]:
    """Return the pod spec of a workload document, whatever its kind."""
    data = doc.data if isinstance(doc.data, dict) else {}
    spec = data.get("spec")
    if not isinstance(spec, dict):
        return None
    kind = (doc.kind or "").lower()
    if kind == "cronjob":
        jt = spec.get("jobTemplate")
        if isinstance(jt, dict):
            spec = jt.get("spec") if isinstance(jt.get("spec"), dict) else {}
        else:
            return None
    tpl = spec.get("template")
    if isinstance(tpl, dict) and isinstance(tpl.get("spec"), dict):
        return tpl["spec"]
    if kind in ("pod",):
        return spec
    return None


def containers(doc: ManifestDoc, include_init: bool = False) -> List[Dict[str, Any]]:
    ps = pod_spec(doc)
    if not ps:
        return []
    out = []
    for key in (("containers", "initContainers") if include_init else ("containers",)):
        v = ps.get(key)
        if isinstance(v, list):
            out.extend(c for c in v if isinstance(c, dict))
    return out


def doc_name(doc: ManifestDoc) -> str:
    data = doc.data if isinstance(doc.data, dict) else {}
    md = data.get("metadata")
    if isinstance(md, dict):
        n = md.get("name")
        if isinstance(n, str):
            if n.startswith("HELMINC@"):
                return f"<{n[len('HELMINC@'):]}>"     # e.g. <orders.fullname>
            return n.replace("HELMTPL", "<tpl>")
    return "(unnamed)"


def qos_class(requests_cpu, requests_mem, limits_cpu, limits_mem,
              has_requests: bool, has_limits: bool) -> str:
    """Kubernetes QoS class per the official algorithm (single-container view)."""
    if not has_requests and not has_limits:
        return "BestEffort"
    if (requests_cpu is not None and limits_cpu is not None and requests_cpu == limits_cpu
            and requests_mem is not None and limits_mem is not None
            and requests_mem == limits_mem):
        return "Guaranteed"
    return "Burstable"
