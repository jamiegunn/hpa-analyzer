"""Checks: HorizontalPodAutoscaler correctness and HPA<->workload interplay."""

import re
from typing import Any, Dict, List, Optional

from .helmyaml import enclosing_conditions, line_of, values_lookup
from .kube import containers, doc_name
from .models import AnalysisResult, Category, ChartContext, Finding, ManifestDoc, Severity
from .quantity import parse_cpu, parse_memory, fmt_millicores

_REPLICAS_LINE_RE = r"^\s{0,4}replicas\s*:"


def _classify_replicas_gate(conds) -> str:
    """'gated' | 'inverse' | 'other' | 'none' for the replicas field's guard."""
    if not conds:
        return "none"
    for c in conds:
        cl = str(c).lower()
        if re.search(r"autoscal|\bhpa\b|hpa\.", cl):
            negated = re.search(r"\bnot\b|\beq\b[^)]*\bfalse\b|\bne\b[^)]*\btrue\b", cl)
            return "gated" if negated else "inverse"
    return "other"


def run(ctx: ChartContext, result: AnalysisResult) -> None:
    hpas = ctx.hpas
    workloads = ctx.workloads

    if not hpas:
        _no_hpa(ctx, result, workloads)
        return

    seen_targets: Dict[str, List[str]] = {}
    for hpa in hpas:
        name = doc_name(hpa)
        spec = hpa.data.get("spec") if isinstance(hpa.data, dict) else {}
        if not isinstance(spec, dict):
            continue
        target = _target_workload(ctx, spec)
        _replica_bounds(ctx, result, hpa, name, spec, target)
        _metrics(ctx, result, hpa, name, spec, target)
        _behavior(ctx, result, hpa, name, spec)
        _target_ref(ctx, result, hpa, name, spec, target, seen_targets)

    for target_key, hpa_names in seen_targets.items():
        if len(hpa_names) > 1:
            result.add(Finding(
                rule_id="HP010", severity=Severity.CRITICAL, category=Category.HPA,
                title="Multiple HPAs target the same workload", file="",
                detail=f"{', '.join(hpa_names)} all target {target_key}.",
                why="Two autoscalers issuing conflicting desired-replica values "
                    "fight each other; replica count oscillates.",
                fix="Keep exactly one HPA per workload."))

    _replicas_conflict(ctx, result)


def _add(result, **kw):
    result.add(Finding(**kw))


def _no_hpa(ctx, result, workloads):
    scalable = [w for w in workloads if (w.kind or "").lower() in ("deployment", "statefulset")]
    if not scalable:
        return
    f_auto, auto_en = values_lookup(ctx.values, "autoscaling.enabled")
    if f_auto:
        detail = (f"values declare autoscaling.enabled={auto_en} but no "
                  f"HorizontalPodAutoscaler template exists in the chart.")
        sev = Severity.HIGH if auto_en else Severity.MEDIUM
        why = ("The values file promises autoscaling that the chart cannot "
               "deliver - a reviewer reading values.yaml is misled, and flipping "
               "the flag does nothing.")
        fix = "Add templates/hpa.yaml gated on .Values.autoscaling.enabled."
        if auto_en:
            why = ("autoscaling.enabled is TRUE but there is no hpa.yaml template "
                   "- the chart silently never scales.")
        _add(result, rule_id="HP001", severity=sev, category=Category.HPA,
             title="autoscaling values exist but no HPA template", file="",
             detail=detail, why=why, fix=fix)
    else:
        _add(result, rule_id="HP002", severity=Severity.MEDIUM, category=Category.HPA,
             title="No HPA (and no autoscaling values)", file="",
             detail="Chart deploys a scalable workload with a fixed replica count "
                    "and no HorizontalPodAutoscaler.",
             why="Fixed replicas must be sized for PEAK load and therefore waste "
                 "capacity off-peak - or are sized for average and fall over at "
                 "peak. An HPA sizes for now.",
             fix="Add an autoscaling/v2 HPA on CPU (target 60-75%) once resource "
                 "requests are set correctly.",
             math="Cost of fixed sizing: replicas_fixed = ceil(peak/target_per_pod)."
                  " With peak:offpeak = 4:1 you idle ~75% of capacity off-peak.")


def _target_workload(ctx, spec) -> Optional[ManifestDoc]:
    ref = spec.get("scaleTargetRef")
    if not isinstance(ref, dict):
        return None
    rk, rn = str(ref.get("kind", "")).lower(), str(ref.get("name", ""))
    for w in ctx.workloads:
        if (w.kind or "").lower() == rk and (doc_name(w) == rn or rn.startswith("HELM")):
            return w
    if len(ctx.workloads) == 1 and rk == (ctx.workloads[0].kind or "").lower():
        return ctx.workloads[0]
    return None


def _replica_bounds(ctx, result, hpa, name, spec, target):
    mn, mx = spec.get("minReplicas"), spec.get("maxReplicas")

    if mx is None:
        _add(result, rule_id="HP003", severity=Severity.HIGH, category=Category.HPA,
             title="HPA missing maxReplicas", file=hpa.file,
             detail=f"HPA '{name}' has no maxReplicas (required field).",
             why="The API server rejects an HPA without maxReplicas.",
             fix="Set maxReplicas.")
    if isinstance(mn, int) and isinstance(mx, int):
        if mn > mx:
            _add(result, rule_id="HP004", severity=Severity.CRITICAL, category=Category.HPA,
                 title="HPA minReplicas > maxReplicas (invalid)", file=hpa.file,
                 detail=f"HPA '{name}': minReplicas={mn} > maxReplicas={mx}.",
                 why="Invalid object - the API server rejects it, so the workload "
                     "has NO autoscaling and helm upgrade fails.",
                 fix="Make min <= max.",
                 math=f"Constraint violated: {mn} <= {mx} is false.")
        elif mn == mx:
            _add(result, rule_id="HP005", severity=Severity.MEDIUM, category=Category.HPA,
                 title="HPA min == max (autoscaler cannot scale)", file=hpa.file,
                 detail=f"HPA '{name}': minReplicas = maxReplicas = {mn}.",
                 why="The HPA can only ever choose one value; you pay the "
                     "metrics-pipeline cost for zero elasticity.",
                 fix="Widen the band (e.g. min=2, max=3x expected peak need) or "
                     "delete the HPA.",
                 math=f"desired = clamp(ceil(current x usage/target), {mn}, {mx}) "
                      f"= {mn} for every possible usage.")
    if isinstance(mn, int) and mn < 2:
        _add(result, rule_id="HP006", severity=Severity.MEDIUM, category=Category.AVAIL,
             title="HPA minReplicas=1", file=hpa.file,
             detail=f"HPA '{name}': minReplicas={mn}.",
             why="At quiet times the HPA scales to a single pod: every voluntary "
                 "disruption or crash at min-scale is then a full outage, and "
                 "recovery requires a cold JVM start under rising load.",
             fix="minReplicas: 2 for anything user-facing.")
    if isinstance(mn, int) and isinstance(mx, int) and mx > mn and mx > 1 and mx / max(mn, 1) > 10:
        _add(result, rule_id="HP007", severity=Severity.LOW, category=Category.HPA,
             title="Very wide HPA range", file=hpa.file,
             detail=f"HPA '{name}': min={mn}, max={mx} ({mx//max(mn,1)}x).",
             why="A 10x+ band usually means requests were never right-sized; "
                 "check the cluster can actually schedule max pods "
                 "(max x request <= cluster headroom) or scaling silently stops "
                 "at Pending pods.",
             fix="Verify capacity: maxReplicas x cpu request and x memory request.")


def _metrics(ctx, result, hpa, name, spec, target):
    api_v1 = (hpa.api_version or "").startswith("autoscaling/v1")
    metrics = spec.get("metrics")
    tcup = spec.get("targetCPUUtilizationPercentage")

    metric_entries: List[Dict[str, Any]] = []
    if isinstance(metrics, list):
        metric_entries = [m for m in metrics if isinstance(m, dict)]

    if api_v1 and tcup is None and not metric_entries:
        _add(result, rule_id="HP020", severity=Severity.HIGH, category=Category.HPA,
             title="autoscaling/v1 HPA with no CPU target", file=hpa.file,
             detail=f"HPA '{name}' (autoscaling/v1) sets no "
                    f"targetCPUUtilizationPercentage.",
             why="Defaults to a cluster-level value (usually 80%) that nobody "
                 "chose for this app; the scaling behavior is undocumented and "
                 "environment-dependent.",
             fix="Migrate to autoscaling/v2 and set an explicit CPU utilization "
                 "target.")
    if not api_v1 and not metric_entries and tcup is None:
        _add(result, rule_id="HP021", severity=Severity.HIGH, category=Category.HPA,
             title="HPA has no metrics", file=hpa.file,
             detail=f"HPA '{name}' defines no metrics[].",
             why="Without metrics the controller defaults to 80% CPU - implicit, "
                 "surprising behavior.",
             fix="Define metrics explicitly.")

    # gather workload requests for utilization math
    req_cpu = req_mem = None
    if target:
        for c in containers(target):
            r = c.get("resources")
            if isinstance(r, dict) and isinstance(r.get("requests"), dict):
                req_cpu = req_cpu or parse_cpu(r["requests"].get("cpu"))
                req_mem = req_mem or parse_memory(r["requests"].get("memory"))

    targets_cpu = tcup is not None
    for m in metric_entries:
        mtype = str(m.get("type", "")).lower()
        if mtype == "resource":
            res = m.get("resource") if isinstance(m.get("resource"), dict) else {}
            rname = str(res.get("name", "")).lower()
            tgt = res.get("target") if isinstance(res.get("target"), dict) else {}
            avg_util = tgt.get("averageUtilization")
            if rname == "cpu":
                targets_cpu = True
                if isinstance(avg_util, int):
                    _cpu_target_quality(ctx, result, hpa, name, avg_util)
            if rname == "memory":
                _memory_metric(ctx, result, hpa, name, tgt, req_mem)
        # external/pods/object metrics: fine, no static validation

    if targets_cpu and target is not None and req_cpu is None:
        _add(result, rule_id="HP022", severity=Severity.CRITICAL, category=Category.HPA,
             title="HPA scales on CPU but target workload has no CPU request",
             file=hpa.file,
             detail=f"HPA '{name}' uses CPU utilization; the target workload's "
                    f"containers define no cpu request.",
             why="CPU 'utilization' is defined as usage / REQUEST. With no "
                 "request the controller cannot compute it: the HPA goes "
                 "ScalingActive=False with FailedGetResourceMetric and NEVER "
                 "scales. This is the single most common way an HPA silently "
                 "does nothing.",
             fix="Set resources.requests.cpu on every container in the pod "
                 "(the calculation averages across containers).",
             math="utilization% = 100 x usage_m / request_m; request_m = nil "
                  "=> undefined for the whole pod.")
    if isinstance(tcup, int):
        _cpu_target_quality(ctx, result, hpa, name, tcup)


def _cpu_target_quality(ctx, result, hpa, name, target_pct: int):
    if target_pct <= 0:
        _add(result, rule_id="HP026", severity=Severity.CRITICAL, category=Category.HPA,
             title=f"HPA CPU target {target_pct}% is invalid", file=hpa.file,
             detail=f"HPA '{name}' targets averageUtilization={target_pct}.",
             why="Utilization targets must be positive; the API server rejects "
                 "this object, so the workload has no autoscaling at all.",
             fix="Set a target between 1 and 100 (60-75 typical for JVMs).",
             math=f"desired = ceil(current x usage / {target_pct}) is "
                  f"undefined or divides by zero.")
        return
    if target_pct > 90:
        _add(result, rule_id="HP023", severity=Severity.HIGH, category=Category.HPA,
             title=f"HPA CPU target {target_pct}% leaves no scaling headroom",
             file=hpa.file,
             detail=f"HPA '{name}' targets averageUtilization={target_pct}%.",
             why="Scaling is not instantaneous: metrics lag (15-60s), pods "
                 "schedule, images pull, and a JVM warms up. During that window "
                 "existing pods must absorb the excess ABOVE the target. At "
                 f"{target_pct}% the buffer before saturation is only "
                 f"{100-target_pct}%.",
             fix="Target 60-75% for JVM services; lower if startup is slow.",
             math=f"Absorbable load growth while scaling = 100/{target_pct} - 1 "
                  f"= {100/target_pct - 1:.0%}. With a 90s JVM startup, load "
                  f"growing faster than {(100/target_pct - 1)*100:.0f}% per "
                  f"~2 min saturates pods before help arrives.")
    elif target_pct < 40:
        _add(result, rule_id="HP024", severity=Severity.LOW, category=Category.HPA,
             title=f"HPA CPU target {target_pct}% is very conservative", file=hpa.file,
             detail=f"HPA '{name}' targets averageUtilization={target_pct}%.",
             why=f"You provision 100/{target_pct} = {100/target_pct:.1f}x the CPU "
                 f"you actually use, at steady state, forever.",
             fix="60-75% is typical; keep low targets only for spiky, "
                 "latency-critical traffic.",
             math=f"Steady-state overprovision factor = 100/target = "
                  f"{100/target_pct:.2f}x.")


def _memory_metric(ctx, result, hpa, name, tgt, req_mem):
    is_jvm = bool(ctx.dockerfiles) and any(d.java_major or d.java_opts or
                                           d.jvm_flags for d in ctx.dockerfiles)
    avg_util = tgt.get("averageUtilization")
    sev = Severity.CRITICAL if is_jvm else Severity.MEDIUM
    why = ("Memory-utilization HPA assumes memory falls when load falls. A JVM "
           "violates that assumption: committed heap stays at or near its "
           "high-water mark (most collectors return memory to the OS "
           "reluctantly or never), so measured 'utilization' stays high after "
           "load drops. Result: the HPA scales UP under load but never scales "
           "back DOWN - it ratchets to maxReplicas and stays there.")
    if not is_jvm:
        why = ("Memory-based scaling only works for workloads whose RSS tracks "
               "load closely and is released promptly - rare in practice.")
    math = None
    if isinstance(avg_util, int):
        math = (f"Example with Xmx-bound JVM: after warmup RSS ~= "
                f"heap_committed + off-heap ~= constant C. utilization = "
                f"C/request stays > {avg_util}% regardless of traffic => "
                f"desired = ceil(current x util/{avg_util}) >= current forever "
                f"(HPA tolerance +/-10%). Scale-down condition util < "
                f"{avg_util}% is unreachable.")
    _add(result, rule_id="HP025", severity=sev, category=Category.HPA,
         title="HPA scales on memory" + (" for a JVM workload" if is_jvm else ""),
         file="",
         detail=f"HPA '{name}' includes a memory utilization/average-value metric"
                + (f" (target {avg_util}%)" if isinstance(avg_util, int) else "") + ".",
         why=why,
         fix="Scale JVMs on CPU or on a load-proportional metric (requests/sec "
             "via external metrics, queue depth). If memory must gate scaling, "
             "use it only as a secondary metric and remember HPA takes the MAX "
             "of all metric proposals - memory will dominate.",
         math=math)


def _behavior(ctx, result, hpa, name, spec):
    behavior = spec.get("behavior")
    if not isinstance(behavior, dict):
        _add(result, rule_id="HP030", severity=Severity.LOW, category=Category.HPA,
             title="No HPA behavior block (defaults apply)", file=hpa.file,
             detail=f"HPA '{name}' relies on default scaling behavior.",
             why="Defaults: scale-up may double pods every 15s (or +4 pods, "
                 "whichever is larger) with 0s stabilization; scale-down waits "
                 "300s. For slow-starting JVMs an aggressive default scale-up "
                 "adds many cold pods that all JIT-compile at once (CPU burst -> "
                 "even higher utilization -> more scaling: a warmup storm).",
             fix="Add behavior.scaleUp with a stabilizationWindowSeconds of "
                 "60-120s and/or policies limiting pods-per-minute; keep "
                 "scale-down conservative.")
        return
    sd = behavior.get("scaleDown") if isinstance(behavior.get("scaleDown"), dict) else {}
    if isinstance(sd.get("stabilizationWindowSeconds"), int) and sd["stabilizationWindowSeconds"] == 0:
        _add(result, rule_id="HP031", severity=Severity.MEDIUM, category=Category.HPA,
             title="scaleDown stabilization window is 0", file=hpa.file,
             detail=f"HPA '{name}': behavior.scaleDown.stabilizationWindowSeconds=0.",
             why="Zero stabilization lets the HPA remove pods the instant a "
                 "metric dips - flapping traffic then kills warm JVMs it will "
                 "need again 30 seconds later (and cold starts are the expensive "
                 "part).",
             fix="Use >= 300s (the default) for JVM workloads.")


def _target_ref(ctx, result, hpa, name, spec, target, seen_targets):
    ref = spec.get("scaleTargetRef")
    if not isinstance(ref, dict):
        _add(result, rule_id="HP040", severity=Severity.HIGH, category=Category.HPA,
             title="HPA missing scaleTargetRef", file=hpa.file,
             detail=f"HPA '{name}' has no scaleTargetRef.",
             why="Required - the HPA does not know what to scale.",
             fix="Point scaleTargetRef at the Deployment (apiVersion apps/v1).")
        return
    key = f"{ref.get('kind')}/{ref.get('name')}"
    seen_targets.setdefault(key, []).append(name)
    if target is None and ctx.workloads:
        _add(result, rule_id="HP041", severity=Severity.HIGH, category=Category.HPA,
             title="HPA target does not match any workload in the chart", file=hpa.file,
             detail=f"HPA '{name}' targets {key}, which matches no "
                    f"Deployment/StatefulSet template here (name comparison is "
                    f"static - template expressions can defeat it; verify).",
             why="A dangling scaleTargetRef means the HPA controls nothing "
                 "(AbleToScale=False) while everyone assumes autoscaling works.",
             fix="Make the ref use the same fullname helper as the Deployment.")


_HP050_WHY = ("Helm and the HPA now fight over the same field. Every 'helm "
              "upgrade' resets replicas to the template value; if the HPA had "
              "scaled to 10 and the template says 2, the deploy instantly "
              "kills 8 loaded pods mid-traffic. The HPA scales back up "
              "minutes later - after your users noticed.")
_HP050_FIX = ("Omit spec.replicas entirely when autoscaling is enabled:\n"
              "        {{- if not .Values.autoscaling.enabled }}\n"
              "        replicas: {{ .Values.replicaCount }}\n"
              "        {{- end }}")
_HP050_MATH = ("Upgrade at peak: pods 10 -> 2 (helm apply) => per-pod load "
               "x5 instantly; if pods saturate at ~2x, the service is down "
               "until HPA re-adds pods (>= 1 metric period + JVM startup).")


def _replicas_conflict(ctx, result):
    """spec.replicas set on a workload that an HPA also scales.

    helm mode: rendered output is ground truth (replicas present in the
    render + HPA rendered => real conflict, no guessing). static mode:
    the guard around 'replicas:' is resolved with a control-flow stack
    scan (enclosing_conditions), not a single-idiom regex - any negated
    autoscaling/hpa condition counts as correctly gated; an un-negated one
    is the INVERSE bug; an unrelated condition downgrades to 'verify'.
    """
    helm_truth = ctx.render_mode == "helm"

    def hpa_targets(w, rendered_only: bool) -> bool:
        wname, wkind = doc_name(w), (w.kind or "").lower()
        candidates = [h for h in ctx.hpas
                      if not rendered_only or getattr(h, "rendered", True)]
        for h in candidates:
            spec = h.data.get("spec") if isinstance(h.data, dict) else {}
            ref = spec.get("scaleTargetRef") if isinstance(spec, dict) else None
            if isinstance(ref, dict):
                rk = str(ref.get("kind", "")).lower()
                rn = str(ref.get("name", ""))
                if rk == wkind and (rn == wname or rn.startswith("HELM")
                                    or wname.startswith("<")):
                    return True
        # single HPA + single scalable workload: assume the pairing
        scalable = [x for x in ctx.workloads
                    if (x.kind or "").lower() in ("deployment", "statefulset")]
        return bool(candidates) and len(candidates) == 1 and len(scalable) == 1

    for w in ctx.workloads:
        if (w.kind or "").lower() not in ("deployment", "statefulset"):
            continue
        spec = w.data.get("spec") if isinstance(w.data, dict) else {}
        if not isinstance(spec, dict) or "replicas" not in spec:
            continue
        if not getattr(w, "rendered", True):
            continue    # replicas only exists in a branch that is off
        if not hpa_targets(w, rendered_only=False):
            continue    # no HPA (rendered or conditional) manages this workload
        hpa_rendered = hpa_targets(w, rendered_only=True)
        replicas = spec.get("replicas")
        rep_str = replicas if isinstance(replicas, int) else "<from values>"
        raw = ctx.template_raw.get(w.file, "")
        conds = enclosing_conditions(raw, _REPLICAS_LINE_RE) if raw else None
        gate = _classify_replicas_gate(conds)
        rep_line = line_of(raw, _REPLICAS_LINE_RE)
        name = doc_name(w)

        if helm_truth and hpa_rendered:
            _add(result, rule_id="HP050", severity=Severity.CRITICAL, category=Category.HPA,
                 title="Rendered Deployment sets spec.replicas while an HPA manages it",
                 file=w.file, line=rep_line,
                 detail=f"`helm template` with the current values renders BOTH "
                        f"spec.replicas={rep_str} on {w.kind} '{name}' AND an "
                        f"HPA targeting it. This is the rendered output, not a "
                        f"static guess.",
                 why=_HP050_WHY, fix=_HP050_FIX, math=_HP050_MATH)
            continue
        if helm_truth and not hpa_rendered:
            if gate == "gated":
                continue    # guard exists and will drop replicas when enabled
            _add(result, rule_id="HP051", severity=Severity.HIGH, category=Category.HPA,
                 title="Enabling the HPA will collide with spec.replicas",
                 file=w.file, line=rep_line,
                 detail=f"The HPA template exists (currently disabled by "
                        f"values) but spec.replicas on {w.kind} '{name}' is "
                        f"not guarded by a 'not ...enabled' condition "
                        f"(guards found: {conds if conds else 'none'}).",
                 why="The moment someone flips autoscaling.enabled=true, helm "
                     "will keep resetting replicas on every upgrade - the "
                     "classic HPA fight, pre-armed.",
                 fix=_HP050_FIX, math=_HP050_MATH)
            continue

        # static mode
        if not ctx.hpas:
            continue
        if gate == "gated":
            continue
        if gate == "inverse":
            _add(result, rule_id="HP050", severity=Severity.CRITICAL, category=Category.HPA,
                 title="replicas guarded by autoscaling ENABLED (inverted gate)",
                 file=w.file, line=rep_line,
                 detail=f"{w.kind} '{name}': the guard around spec.replicas is "
                        f"{conds} - replicas is set precisely WHEN the HPA is "
                        f"active, the exact opposite of the correct gate.",
                 why=_HP050_WHY, fix=_HP050_FIX, math=_HP050_MATH)
        elif gate == "other":
            _add(result, rule_id="HP052", severity=Severity.MEDIUM, category=Category.HPA,
                 title="spec.replicas is conditional - verify the gate matches the HPA",
                 file=w.file, line=rep_line,
                 detail=f"{w.kind} '{name}' sets spec.replicas inside condition(s) "
                        f"{conds}, which this static analysis cannot prove "
                        f"equivalent to 'not autoscaling.enabled'. An HPA "
                        f"exists in this chart.",
                 why="If that condition can be true while the HPA is active, "
                     "helm upgrades will reset replicas mid-traffic "
                     "(see the HP050 rationale).",
                 fix="Make the guard exactly the negation of the HPA's enable "
                     "flag - or run this tool with helm on PATH for a "
                     "rendered-truth answer.",
                 math=_HP050_MATH)
        else:
            _add(result, rule_id="HP050", severity=Severity.CRITICAL, category=Category.HPA,
                 title="Deployment sets spec.replicas while an HPA manages it",
                 file=w.file, line=rep_line,
                 detail=f"{w.kind} '{name}' sets spec.replicas={rep_str} with "
                        f"no guard at all, AND an HPA targets this workload.",
                 why=_HP050_WHY, fix=_HP050_FIX, math=_HP050_MATH)
