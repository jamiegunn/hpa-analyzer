"""Core data models: findings, severities, categories, parsed-file containers."""

from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Dict, List, Optional


class Severity(Enum):
    CRITICAL = ("CRITICAL", 5, 25)   # (label, rank, score deduction)
    HIGH     = ("HIGH",     4, 12)
    MEDIUM   = ("MEDIUM",   3, 6)
    LOW      = ("LOW",      2, 3)
    INFO     = ("INFO",     1, 0)

    @property
    def label(self) -> str:
        return self.value[0]

    @property
    def rank(self) -> int:
        return self.value[1]

    @property
    def deduction(self) -> int:
        return self.value[2]


class Category(Enum):
    CHART      = "Helm Chart Structure & Hygiene"
    TEMPLATES  = "Kubernetes Templates & API Versions"
    RESOURCES  = "Resource Requests & Limits"
    HPA        = "Horizontal Pod Autoscaling"
    AVAIL      = "Availability & Disruption Tolerance"
    PROBES     = "Health Probes & Lifecycle"
    DOCKERFILE = "Dockerfile Quality"
    JAVA       = "Java / JVM Container Fitness"
    SECURITY   = "Security Posture"
    CROSS      = "Cross-File Consistency (Chart <-> JVM)"


@dataclass
class Finding:
    rule_id: str
    severity: Severity
    category: Category
    title: str
    file: str                       # relative path of the offending file ('' if global)
    detail: str                     # what was found, with concrete values
    why: str                        # educational: why it matters
    fix: str                        # concrete remediation
    math: Optional[str] = None      # optional mathematical proof / worked example
    line: Optional[int] = None

    def sort_key(self):
        return (-self.severity.rank, self.category.value, self.rule_id)


@dataclass
class ProofTable:
    """A named mathematical proof table rendered in the report."""
    title: str
    intro: str                      # what the table proves
    headers: List[str]
    rows: List[List[str]]
    conclusion: str                 # verdict drawn from the numbers


@dataclass
class DockerfileInfo:
    path: str
    raw: str = ""
    instructions: List[Dict[str, Any]] = field(default_factory=list)  # {instr, args, line}
    base_images: List[Dict[str, Any]] = field(default_factory=list)   # {image, tag, stage, line}
    final_base: Optional[Dict[str, Any]] = None
    java_major: Optional[int] = None       # 8, 11, 17, 21 ...
    java_update: Optional[int] = None      # for java 8: 8uNNN
    java_flavor: str = ""                  # jdk / jre / distroless etc.
    java_opts: Dict[str, str] = field(default_factory=dict)  # env var name -> raw value
    jvm_flags: List[str] = field(default_factory=list)       # all parsed jvm flags
    entrypoint: Optional[Dict[str, Any]] = None  # {form: 'exec'|'shell', args, line}
    cmd: Optional[Dict[str, Any]] = None
    user: Optional[str] = None
    healthcheck: bool = False
    exposed_ports: List[str] = field(default_factory=list)
    multistage: bool = False


@dataclass
class ManifestDoc:
    """A single YAML document from a helm template.

    rendered=True  -> came from `helm template` output (real YAML) or, in
                      static mode, from the scrubbed parse (best effort).
    rendered=False -> template exists but did NOT render with the analyzed
                      values (e.g. gated behind a disabled flag); analyzed
                      anyway, findings are annotated as conditional.
    """
    file: str
    kind: Optional[str]
    api_version: Optional[str]
    data: Any
    raw: str = ""
    rendered: bool = True


@dataclass
class ChartContext:
    """Everything discovered in the target directory."""
    root: str = ""
    chart_yaml_path: Optional[str] = None
    chart: Dict[str, Any] = field(default_factory=dict)
    values_files: Dict[str, Any] = field(default_factory=dict)      # path -> parsed dict
    values_raw: Dict[str, str] = field(default_factory=dict)        # path -> raw text
    values: Dict[str, Any] = field(default_factory=dict)            # merged effective values
    template_files: List[str] = field(default_factory=list)
    template_raw: Dict[str, str] = field(default_factory=dict)      # path -> raw text
    docs: List[ManifestDoc] = field(default_factory=list)
    dockerfiles: List[DockerfileInfo] = field(default_factory=list)
    helpers_tpl: bool = False
    notes_txt: bool = False
    schema_json: bool = False
    helmignore: bool = False
    parse_errors: List[str] = field(default_factory=list)
    tests_dir: bool = False

    # --- coverage / confidence -------------------------------------------
    render_mode: str = "static"          # "helm" | "static" | "static (helm failed: ...)"
    helm_error: Optional[str] = None
    coverage: List[List[str]] = field(default_factory=list)   # [item, status]
    subcharts_present: bool = False
    assumed_java: Optional[str] = None   # from --assume-java
    overlay_values: List[str] = field(default_factory=list)   # non-base values files
    chart_dir_abs: Optional[str] = None  # for helm re-render of overlay variants

    # -- convenience selectors ------------------------------------------------
    def docs_of_kind(self, *kinds: str) -> List[ManifestDoc]:
        kl = {k.lower() for k in kinds}
        return [d for d in self.docs if (d.kind or "").lower() in kl]

    @property
    def workloads(self) -> List[ManifestDoc]:
        return self.docs_of_kind(
            "Deployment", "StatefulSet", "DaemonSet", "ReplicaSet",
            "Job", "CronJob", "Rollout")

    @property
    def hpas(self) -> List[ManifestDoc]:
        return self.docs_of_kind("HorizontalPodAutoscaler")


@dataclass
class AnalysisResult:
    context: ChartContext
    findings: List[Finding] = field(default_factory=list)
    proofs: List[ProofTable] = field(default_factory=list)

    def add(self, finding: Finding):
        self.findings.append(finding)

    def add_proof(self, proof: ProofTable):
        self.proofs.append(proof)
