"""Regression tests for defects found in adversarial review - each test
pins a bug that shipped once and must never ship again."""

import unittest
from unittest import mock

from hpaanalyzer import discovery
from hpaanalyzer.dockerparse import effective_flags, parse_dockerfile
from hpaanalyzer.engine import analyze
from hpaanalyzer.helmyaml import (deep_merge, enclosing_conditions,
                                  load_yaml_docs, resolve_markers,
                                  scrub_template)
from hpaanalyzer.models import Severity

from .util import CHART_YAML, DEPLOYMENT_TPL, HPA_TPL, make_tree


def parse(text):
    return parse_dockerfile("Dockerfile", text)


class TestNestedChartHelmMapping(unittest.TestCase):
    """Defect: chart in a subdirectory made every rendered doc appear
    duplicated as 'not rendered' because Source paths didn't match."""

    RENDERED = """---
# Source: t/templates/deployment.yaml
apiVersion: apps/v1
kind: Deployment
metadata: {name: release-name-app}
spec:
  replicas: 2
  selector: {matchLabels: {app: t}}
  template:
    metadata: {labels: {app: t}}
    spec:
      containers:
        - name: app
          image: repo/app:1
          resources: {requests: {cpu: 500m, memory: 1Gi}, limits: {memory: 1Gi}}
"""

    def test_subdir_chart_docs_not_duplicated(self):
        root = make_tree({
            "mychart/Chart.yaml": CHART_YAML,
            "mychart/values.yaml": "replicaCount: 2\n",
            "mychart/templates/deployment.yaml": DEPLOYMENT_TPL % {
                "replicas_block": "replicas: 2"},
        })
        with mock.patch.object(discovery, "find_helm", return_value="/x/helm"), \
             mock.patch.object(discovery, "render_chart",
                               return_value=(self.RENDERED, None)):
            r = analyze(root, helm_mode="auto")
        deployments = [d for d in r.context.docs if d.kind == "Deployment"]
        self.assertEqual(len(deployments), 1, "phantom duplicate doc")
        self.assertTrue(deployments[0].rendered)
        self.assertEqual(deployments[0].file, "mychart/templates/deployment.yaml")

    def test_subchart_render_output_skipped_with_coverage_note(self):
        rendered = self.RENDERED + """---
# Source: t/charts/postgres/templates/sts.yaml
apiVersion: apps/v1
kind: StatefulSet
metadata: {name: pg}
spec:
  selector: {matchLabels: {app: pg}}
  template:
    metadata: {labels: {app: pg}}
    spec: {containers: [{name: pg, image: postgres:16}]}
"""
        root = make_tree({
            "Chart.yaml": CHART_YAML,
            "values.yaml": "replicaCount: 2\n",
            "templates/deployment.yaml": DEPLOYMENT_TPL % {
                "replicas_block": "replicas: 2"},
        })
        with mock.patch.object(discovery, "find_helm", return_value="/x/helm"), \
             mock.patch.object(discovery, "render_chart",
                               return_value=(rendered, None)):
            r = analyze(root, helm_mode="auto")
        self.assertFalse(any(d.kind == "StatefulSet" for d in r.context.docs),
                         "subchart object analyzed despite out-of-scope promise")
        self.assertTrue(any("subchart" in row[1].lower()
                            for row in r.context.coverage))


class TestZeroTargetNoCrash(unittest.TestCase):
    """Defect: averageUtilization: 0 crashed the whole run (ZeroDivision)."""

    def test_zero_cpu_target(self):
        hpa = HPA_TPL.replace("averageUtilization: 70", "averageUtilization: 0")
        root = make_tree({
            "Chart.yaml": CHART_YAML,
            "values.yaml": "replicaCount: 2\nautoscaling:\n  enabled: true\n",
            "templates/deployment.yaml": DEPLOYMENT_TPL % {
                "replicas_block": "{{- if not .Values.autoscaling.enabled }}\n"
                                  "  replicas: 2\n  {{- end }}"},
            "templates/hpa.yaml": hpa,
        })
        r = analyze(root, helm_mode="off")   # must not raise
        self.assertIn("HP026", {f.rule_id for f in r.findings})


class TestNoDockerfileNoJvmFiction(unittest.TestCase):
    """Defect: charts with no Dockerfile got invented JVM memory budgets
    and un-scored XF findings."""

    def test_no_jvm_tables_or_xf_without_dockerfile(self):
        root = make_tree({
            "Chart.yaml": CHART_YAML,
            "values.yaml": "replicaCount: 2\n",
            "templates/deployment.yaml": DEPLOYMENT_TPL % {
                "replicas_block": "replicas: 2"},
        })
        r = analyze(root, helm_mode="off")
        self.assertFalse(any("JVM" in p.title for p in r.proofs),
                         "JVM proof tables invented without a Dockerfile")
        self.assertFalse(any(f.rule_id.startswith("XF") for f in r.findings),
                         "cross-file JVM findings without a Dockerfile")


class TestDockerfileParsing(unittest.TestCase):
    def test_legacy_env_with_equals_in_value(self):
        # Defect: legacy 'ENV KEY value-with=' was dropped entirely
        df = parse("FROM eclipse-temurin:17-jre\n"
                   "ENV JAVA_TOOL_OPTIONS -Xmx512m -XX:MaxRAMPercentage=75.0\n"
                   'ENTRYPOINT ["java","-jar","a.jar"]\n')
        self.assertIn("JAVA_TOOL_OPTIONS", df.java_opts)
        self.assertIn("-Xmx512m", effective_flags(df))

    def test_app_version_tags_not_java_versions(self):
        # Defect: myco/javaservice:1.2.3 detected as "Java 2"
        self.assertIsNone(parse("FROM myco/javaservice:1.2.3\n").java_major)
        self.assertIsNone(parse("FROM corp/javalin-app:3.4.5\n").java_major)

    def test_legacy_1_8_0_tag_keeps_update(self):
        # Defect: 1.8.0_131-style tags lost the update level
        df = parse("FROM java:1.8.0_60\n")
        self.assertEqual((df.java_major, df.java_update), (8, 60))

    def test_builder_jdk_not_attributed_to_distroless_final(self):
        # Defect: openjdk-17 fallback scanned the WHOLE file
        df = parse("FROM openjdk-17-builder AS build\nRUN make\n"
                   "FROM gcr.io/distroless/base\nCOPY --from=build /a /a\n")
        self.assertIsNone(df.java_major)

    def test_cmd_ignored_under_shell_entrypoint(self):
        # Defect: CMD flags counted although docker ignores CMD there
        df = parse("FROM eclipse-temurin:17-jre\n"
                   "ENTRYPOINT java -Xmx256m -jar a.jar\n"
                   'CMD ["java","-Xmx4g","-XX:+UseZGC"]\n')
        eff = effective_flags(df)
        self.assertIn("-Xmx256m", eff)
        self.assertNotIn("-Xmx4g", eff)

    def test_overridden_entrypoint_flags_discarded(self):
        # Defect: jvm_flags accumulated across overridden ENTRYPOINTs
        df = parse("FROM eclipse-temurin:17-jre\n"
                   "ENTRYPOINT java -Xmx256m -jar a.jar\n"
                   'ENTRYPOINT ["java","-jar","a.jar"]\n')
        self.assertNotIn("-Xmx256m", effective_flags(df))

    def test_builder_stage_env_and_user_ignored(self):
        # Defect: ENV/USER from the builder stage counted as runtime facts
        df = parse("FROM eclipse-temurin:17-jdk AS build\n"
                   'ENV JAVA_TOOL_OPTIONS="-Xmx4g"\nUSER app\nRUN make\n'
                   "FROM eclipse-temurin:17-jre\n"
                   'ENTRYPOINT ["java","-jar","a.jar"]\n')
        self.assertEqual(df.java_opts, {})
        self.assertIsNone(df.user)


class TestTemplateActionHandling(unittest.TestCase):
    def test_template_keyword_treated_like_include(self):
        # Defect: {{ template "x" . }} was dropped as control flow
        src = 'labels:\n  {{- template "mychart.labels" . }}\n'
        docs, _, err = load_yaml_docs(scrub_template(src))
        self.assertIsNone(err)
        self.assertEqual(docs[0]["labels"], "HELMINC@mychart.labels")

    def test_default_literal_resolves_when_value_missing(self):
        # Defect: `| default 3` never resolved (dead regex)
        src = "replicas: {{ .Values.replicaCount | default 3 }}\n"
        docs, _, _ = load_yaml_docs(scrub_template(src))
        self.assertEqual(resolve_markers(docs[0], {}), {"replicas": 3})
        self.assertEqual(resolve_markers(docs[0], {"replicaCount": 7}),
                         {"replicas": 7})

    def test_define_scope_is_not_a_condition(self):
        # Defect: define-wrapped replicas downgraded HP050 to 'verify'
        src = ('{{- define "d.tpl" }}\nspec:\n  replicas: 2\n{{- end }}\n')
        conds = enclosing_conditions(src, r"^\s{0,4}replicas\s*:")
        self.assertEqual(conds, [])


class TestProbeTableCoverage(unittest.TestCase):
    def test_probe_table_found_on_second_workload(self):
        # Defect: unconditional break meant only the FIRST workload was
        # ever examined for the probe-budget table
        no_probe = (
            "apiVersion: apps/v1\nkind: Deployment\nmetadata: {name: a}\n"
            "spec:\n  selector: {matchLabels: {app: a}}\n"
            "  template:\n    metadata: {labels: {app: a}}\n"
            "    spec: {containers: [{name: a, image: r/a:1}]}\n")
        with_probe = (
            "apiVersion: apps/v1\nkind: Deployment\nmetadata: {name: b}\n"
            "spec:\n  selector: {matchLabels: {app: b}}\n"
            "  template:\n    metadata: {labels: {app: b}}\n"
            "    spec:\n      containers:\n"
            "        - name: b\n          image: r/b:1\n"
            "          livenessProbe:\n            httpGet: {path: /h, port: 80}\n"
            "            initialDelaySeconds: 1\n            periodSeconds: 1\n")
        root = make_tree({
            "Chart.yaml": CHART_YAML,
            "values.yaml": "x: 1\n",
            "Dockerfile": "FROM eclipse-temurin:17-jre\n"
                          'ENTRYPOINT ["java","-jar","a.jar"]\n',
            "templates/a.yaml": no_probe,
            "templates/b.yaml": with_probe,
        })
        r = analyze(root, helm_mode="off")
        self.assertTrue(any("Probe budget" in p.title and "'b'" in p.title
                            for p in r.proofs),
                        "probe table missing for second workload")


class TestDeepMergeNullDeletes(unittest.TestCase):
    def test_override_null_deletes_key(self):
        self.assertEqual(deep_merge({"a": 1, "b": 2}, {"a": None}), {"b": 2})

    def test_new_null_key_kept(self):
        self.assertEqual(deep_merge({"b": 2}, {"a": None}), {"b": 2, "a": None})


if __name__ == "__main__":
    unittest.main()
